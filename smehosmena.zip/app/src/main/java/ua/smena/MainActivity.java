package ua.smena;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.time.*;

public class MainActivity extends Activity {
    private static final int PICK = 1;
    private static final String[] MONTHS = {"Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
            "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"};
    private static final int[] COLORS = {0xFFFFE082, 0xFF9FA8DA, 0xFFC8E6C9, 0xFFE53935};
    private YearMonth month = YearMonth.now();
    private long photoDay;
    private LinearLayout root, photos;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (b != null) {
            photoDay = b.getLong("photoDay");
            month = YearMonth.parse(b.getString("month", month.toString()));
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        scroll.addView(root);
        setContentView(scroll);
    }

    @Override protected void onSaveInstanceState(Bundle b) {
        super.onSaveInstanceState(b);
        b.putLong("photoDay", photoDay);
        b.putString("month", month.toString());
    }

    @Override protected void onResume() {
        super.onResume();
        Alarms.schedule(this);
        draw();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        return b;
    }

    private TextView label(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        return t;
    }

    private LinearLayout.LayoutParams cell(int height) { return new LinearLayout.LayoutParams(0, height, 1); }

    private void draw() {
        root.removeAllViews();
        LinearLayout head = new LinearLayout(this);
        head.addView(button("<", v -> { month = month.minusMonths(1); draw(); }));
        head.addView(label(MONTHS[month.getMonthValue() - 1] + " " + month.getYear(), 20), cell(-2));
        head.addView(button(">", v -> { month = month.plusMonths(1); draw(); }));
        root.addView(head);

        LinearLayout week = new LinearLayout(this);
        for (String s : new String[]{"Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"}) week.addView(label(s, 13), cell(-2));
        root.addView(week);

        int skip = month.atDay(1).getDayOfWeek().getValue() - 1;
        LinearLayout row = null;
        int total = ((skip + month.lengthOfMonth() + 6) / 7) * 7;
        for (int i = 0; i < total; i++) {
            if (i % 7 == 0) { row = new LinearLayout(this); root.addView(row); }
            int n = i - skip + 1;
            TextView t = label("", 12);
            if (n >= 1 && n <= month.lengthOfMonth()) {
                LocalDate d = month.atDay(n);
                int type = Core.type(d);
                boolean marked = !note(d.toEpochDay()).isEmpty() || files(d.toEpochDay()).length > 0;
                t.setText(n + (marked ? " •" : "") + "\n" + Core.SHORT[type]);
                t.setBackgroundColor(COLORS[type]);
                t.setTextColor(type == Core.OFF ? Color.WHITE : Color.BLACK);
                if (d.equals(LocalDate.now())) t.setTypeface(Typeface.DEFAULT_BOLD);
                if (d.equals(LocalDate.now())) t.setText("[" + n + "]" + (marked ? " •" : "") + "\n" + Core.SHORT[type]);
                t.setOnClickListener(v -> openDay(d));
            }
            LinearLayout.LayoutParams lp = cell(dp(58));
            lp.setMargins(dp(1), dp(1), dp(1), dp(1));
            row.addView(t, lp);
        }

        String last = Core.prefs(this).getString("lastText", "");
        if (!last.isEmpty()) {
            root.addView(label("Последняя шутка:\n" + last, 17));
            root.addView(button("Отправить другу", v -> startActivity(Intent.createChooser(
                    new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, last), "Отправить"))));
        }
        Switch jokes = new Switch(this);
        jokes.setText("Шутка раз в день");
        jokes.setChecked(Core.prefs(this).getBoolean("jokes", true));
        jokes.setOnCheckedChangeListener((v, on) -> {
            Core.prefs(this).edit().putBoolean("jokes", on).apply();
            Alarms.schedule(this);
        });
        root.addView(jokes);
        root.addView(button("Настройки времени", v -> settings()));
        root.addView(button("Проверить уведомление", v ->
                Alarms.show(this, 2, "Смехосмена", "Проверка связи. Шутки доходят!")));
    }

    private void settings() {
        String[] items = new String[Core.KEYS.length];
        for (int i = 0; i < items.length; i++) {
            int v = Core.get(this, Core.KEYS[i]);
            items[i] = Core.LABELS[i] + ": " + Core.hm(v);
        }
        new AlertDialog.Builder(this).setTitle("Настройки времени").setItems(items, (dlg, i) -> {
            int v = Core.get(this, Core.KEYS[i]);
            new TimePickerDialog(this, (picker, h, m) -> {
                Core.prefs(this).edit().putInt(Core.KEYS[i], h * 60 + m).apply();
                Alarms.schedule(this);
                settings();
            }, v / 60, v % 60, true).show();
        }).setPositiveButton("Готово", null).show();
    }

    private String note(long day) { return Core.prefs(this).getString("note_" + day, ""); }

    private File[] files(long day) {
        File[] f = new File(getFilesDir(), "photo/" + day).listFiles();
        return f == null ? new File[0] : f;
    }

    private void openDay(LocalDate d) {
        long day = d.toEpochDay();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(8));
        EditText text = new EditText(this);
        text.setHint("Заметка");
        text.setText(note(day));
        box.addView(text);
        box.addView(button("Добавить фото", v -> {
            photoDay = day;
            startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), PICK);
        }));
        photos = new LinearLayout(this);
        photos.setOrientation(LinearLayout.VERTICAL);
        photos.setTag(day);
        box.addView(photos);
        showPhotos(day);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(String.format("%02d.%02d.%d, %s", d.getDayOfMonth(), d.getMonthValue(), d.getYear(), Core.NAMES[Core.type(d)]))
                .setView(scroll).setPositiveButton("Сохранить", null).create();
        // заметка сохраняется при любом закрытии окна
        dialog.setOnDismissListener(x -> {
            Core.prefs(this).edit().putString("note_" + day, text.getText().toString().trim()).apply();
            draw();
        });
        dialog.show();
    }

    private Bitmap load(File f, int max) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getPath(), o);
        o.inSampleSize = 1;
        while (Math.max(o.outWidth, o.outHeight) / o.inSampleSize > max) o.inSampleSize *= 2;
        o.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(f.getPath(), o);
    }

    private void showPhotos(long day) {
        photos.removeAllViews();
        for (File f : files(day)) {
            ImageView img = new ImageView(this);
            img.setImageBitmap(load(f, 1000));
            img.setAdjustViewBounds(true);
            img.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setMessage("Удалить фото?")
                        .setPositiveButton("Удалить", (a, b) -> { if (f.delete()) showPhotos(day); })
                        .setNegativeButton("Отмена", null).show();
                return true;
            });
            photos.addView(img);
        }
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        if (code != PICK || result != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        File dir = new File(getFilesDir(), "photo/" + photoDay);
        dir.mkdirs();
        File out = new File(dir, System.currentTimeMillis() + ".img");
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(out)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        } catch (IOException e) {
            out.delete();
            Toast.makeText(this, "Не удалось добавить фото", Toast.LENGTH_LONG).show();
        }
        if (photos != null && Long.valueOf(photoDay).equals(photos.getTag())) showPhotos(photoDay);
        draw();
    }
}
