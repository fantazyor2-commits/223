package ua.smena;

import android.content.*;

public class Boot extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) { Alarms.schedule(c); }
}
