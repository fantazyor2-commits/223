package ua.smena;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;

final class Core {
    static final int DAY = 0, NIGHT = 1, POST = 2, OFF = 3;
    static final String[] NAMES = {"Дневная", "Ночная", "Отсыпной", "Выходной"};
    static final String[] SHORT = {"День", "Ночь", "Отсып", "Вых"};
    // 26.11.2026 - выходной, значит 27.11.2026 - дневная смена
    private static final long FIRST_DAY = LocalDate.of(2026, 11, 27).toEpochDay();

    static int type(LocalDate d) { return (int) Math.floorMod(d.toEpochDay() - FIRST_DAY, 4L); }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("p", Context.MODE_PRIVATE); }

    // минуты от полуночи
    static final String[] KEYS = {"dayStart", "nightStart", "sleep", "postFrom", "postTo", "offFrom", "offTo", "remDay", "remNight", "remPost"};
    static final String[] LABELS = {"Начало дневной (конец ночной)", "Начало ночной (конец дневной)", "Сон перед работой (длительность)",
            "Отсыпной: шутки с", "Отсыпной: шутки до", "Выходной: шутки с", "Выходной: шутки до",
            "Напоминание: дневная", "Напоминание: ночная", "Напоминание: отсыпной"};
    private static final int[] DEF = {420, 1140, 360, 840, 1320, 540, 1380, 360, 1065, 435};

    static int get(Context c, String key) {
        int i = Arrays.asList(KEYS).indexOf(key);
        return prefs(c).getInt(key, DEF[i]);
    }

    static String hm(int m) { return String.format(Locale.US, "%02d:%02d", m / 60, m % 60); }

    static LocalDateTime reminderAt(Context c, LocalDate d) {
        int t = type(d);
        if (t == OFF) return null;
        String key = t == DAY ? "remDay" : t == NIGHT ? "remNight" : "remPost";
        return d.atStartOfDay().plusMinutes(get(c, key));
    }

    private static boolean sleeping(Context c, LocalDateTime at) {
        int len = get(c, "sleep");
        for (int shift = -1; shift <= 1; shift++) {
            LocalDate d = at.toLocalDate().plusDays(shift);
            int t = type(d);
            if (t != DAY && t != NIGHT) continue;
            LocalDateTime end = d.atStartOfDay().plusMinutes(get(c, t == DAY ? "dayStart" : "nightStart"));
            if (!at.isBefore(end.minusMinutes(len)) && at.isBefore(end)) return true;
        }
        return false;
    }

    /** Случайное время шутки для даты: постоянное для этой даты, вне сна перед работой. */
    static LocalDateTime jokeAt(Context c, LocalDate d) {
        int t = type(d);
        int from, to;
        if (t == DAY) { from = get(c, "dayStart"); to = get(c, "nightStart"); }
        else if (t == NIGHT) { from = get(c, "nightStart"); to = get(c, "dayStart"); }
        else if (t == POST) { from = get(c, "postFrom"); to = get(c, "postTo"); }
        else { from = get(c, "offFrom"); to = get(c, "offTo"); }
        if (to <= from) to += 1440;
        List<LocalDateTime> ok = new ArrayList<>();
        for (int m = from; m < to; m++) {
            LocalDateTime at = d.atStartOfDay().plusMinutes(m);
            if (!sleeping(c, at)) ok.add(at);
        }
        if (ok.isEmpty()) return null;
        SharedPreferences p = prefs(c);
        long salt = p.getLong("salt", 0);
        if (salt == 0) {
            salt = new Random().nextLong() | 1;
            p.edit().putLong("salt", salt).apply();
        }
        Random r = new Random(salt ^ (d.toEpochDay() * 0x9E3779B97F4A7C15L));
        r.nextInt();
        return ok.get(r.nextInt(ok.size()));
    }

    /** Следующая фраза из папки по порядку: без повторов, пока папка не кончится. */
    static String nextJoke(Context c, int type) {
        String folder = type == POST ? "Отсыпной" : type == OFF ? "Бытовуха" : "Работа";
        List<String> list = new ArrayList<>();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(
                c.getAssets().open("baza_365.csv"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = in.readLine()) != null) {
                String[] a = line.split(";");
                if (a.length >= 4 && a[1].equals(folder)) list.add(a[2]);
            }
        } catch (IOException e) {
            return "Не удалось открыть базу шуток";
        }
        if (list.isEmpty()) return "База шуток пуста";
        SharedPreferences p = prefs(c);
        int i = p.getInt("next_" + folder, 0);
        p.edit().putInt("next_" + folder, (i + 1) % list.size()).apply();
        String s = list.get(i % list.size());
        return s;
    }
}
