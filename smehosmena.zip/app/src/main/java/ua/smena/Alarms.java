package ua.smena;

import android.app.*;
import android.content.*;
import android.os.Build;
import java.time.*;

public class Alarms extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String kind = i.getStringExtra("kind");
        LocalDate d = LocalDate.ofEpochDay(i.getLongExtra("date", LocalDate.now().toEpochDay()));
        int t = Core.type(d);
        if ("joke".equals(kind)) {
            SharedPreferences p = Core.prefs(c);
            if (p.getBoolean("jokes", true) && p.getLong("lastJoke", 0) < d.toEpochDay()) {
                String text = Core.nextJoke(c, t);
                p.edit().putLong("lastJoke", d.toEpochDay()).putString("lastText", text).apply();
                show(c, 2, "Смехосмена", text);
            }
        } else if ("rem".equals(kind)) {
            String text = t == Core.POST ? "Ура выходной!" : Core.NAMES[t] + " смена. Пора собираться.";
            show(c, 1, "Напоминание", text);
        }
        schedule(c);
    }

    static void show(Context c, int id, String title, String text) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        String channel = id == 1 ? "rem" : "joke";
        nm.createNotificationChannel(new NotificationChannel(channel, id == 1 ? "Напоминания о сменах" : "Шутки",
                id == 1 ? NotificationManager.IMPORTANCE_HIGH : NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        nm.notify(id, new Notification.Builder(c, channel).setSmallIcon(R.drawable.ic).setContentTitle(title)
                .setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(open).setAutoCancel(true).build());
    }

    /** Ставит будильники на ближайшие 14 дней. */
    static void schedule(Context c) {
        LocalDate today = LocalDate.now();
        for (int n = -1; n < 14; n++) {
            LocalDate d = today.plusDays(n);
            set(c, d, "rem", Core.reminderAt(c, d));
            boolean sent = Core.prefs(c).getLong("lastJoke", 0) >= d.toEpochDay();
            boolean on = Core.prefs(c).getBoolean("jokes", true);
            set(c, d, "joke", on && !sent ? Core.jokeAt(c, d) : null);
        }
    }

    private static void set(Context c, LocalDate d, String kind, LocalDateTime at) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        int code = (int) d.toEpochDay() * 2 + (kind.equals("joke") ? 1 : 0);
        Intent i = new Intent(c, Alarms.class).putExtra("kind", kind).putExtra("date", d.toEpochDay());
        PendingIntent pi = PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        if (at == null) return;
        long ms = at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        if (ms <= System.currentTimeMillis()) return;
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi);
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi);
    }
}
